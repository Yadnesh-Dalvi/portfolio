import React, { useRef } from "react";
import Navbar from "./components/Navbar";
import Header from "./components/Header";
import GuitarStrings from "./components/GuitarStrings";
import About from "./components/About";
import Icons from "./components/Icons";
import Cursor from "./components/Cursor";
import ProjectTile from "./components/ProjectTile";
import ProjectsSection from "./components/ProjectSection";
import ProjectsScroll from "./components/ProjectScroll";
import Experience from "./components/Experience";
import Projects from "./components/Projects";


const App = () => {
  return (
    <div>
      <Cursor />
      <Navbar />
      <Header /> 
      <Experience />   
      <Projects />  
      {/* <GuitarStrings /> */}
    </div>
  );
};

export default App;