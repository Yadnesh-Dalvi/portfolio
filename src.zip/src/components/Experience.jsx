import React, { useRef, useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import "../styles/Experience.css";

gsap.registerPlugin(ScrollTrigger);

const experiences = [
  {
    role: "Full-Stack Developer Intern",
    company: "Bosch Limited",
    period: "Feb. 2024 – Apr. 2024",
    location: "India",
    desc: "Built and maintained React-based dashboards used by 10k+ users. Developed REST APIs with Node.js and Express, integrated PostgreSQL databases, and improved load times by 40% through lazy loading and code splitting.",
    tags: ["React", "Node.js", "PostgreSQL", "AWS"],
  },
  {
    role: "AI Research Assistant",
    company: "Indiana University",
    period: "Jan 2024 – Present",
    location: "Bloomington, IN",
    desc: "Researching natural language processing models for academic text summarization. Fine-tuned BERT and GPT-based models achieving 18% improvement in ROUGE scores over baseline. Published findings at departmental symposium.",
    tags: ["Python", "PyTorch", "NLP", "HuggingFace"],
  },
];

const Experience = () => {
  const sectionRef = useRef(null);
  const titleRef = useRef(null);
  const itemsRef = useRef([]);

  useEffect(() => {
    // ── Title: fade + slide up, reverses on scroll up ─────────────────
    gsap.fromTo(
      titleRef.current,
      { opacity: 0, y: 60 },
      {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: titleRef.current,
          start: "top 80%",
          end: "top 30%",
          toggleActions: "play none none reverse",
        },
      }
    );

    // ── Cards: each card is its own trigger so scroll position drives
    //    the stagger naturally in BOTH directions ───────────────────────
    itemsRef.current.forEach((el, i) => {
      const fromX = i % 2 === 0 ? -60 : 60;

      gsap.fromTo(
        el,
        { opacity: 0, x: fromX, y: 20 },
        {
          opacity: 1,
          x: 0,
          y: 0,
          duration: 0.9,
          ease: "power3.out",
          scrollTrigger: {
            trigger: el,        // each card triggers itself
            start: "top 85%",
            end: "top 30%",
            toggleActions: "play none none reverse",
          },
        }
      );
    });

    // ── Dots: pop in/out, each with its own trigger ───────────────────
    const dots = document.querySelectorAll(".exp-dot-inner");
    dots.forEach((dot) => {
      gsap.fromTo(
        dot,
        { scale: 0, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.5,
          ease: "back.out(2)",
          scrollTrigger: {
            trigger: dot,       // each dot triggers itself
            start: "top 85%",
            end: "top 30%",
            toggleActions: "play none none reverse",
          },
        }
      );
    });

    return () => ScrollTrigger.getAll().forEach((t) => t.kill());
  }, []);

  return (
    <section id="experience" className="exp-section" ref={sectionRef}>
      <div className="exp-inner">
        <div ref={titleRef} className="exp-header">
          <span className="section-label">Work History</span>
          <h2 className="exp-title">Experience</h2>
        </div>

        <div className="exp-timeline">
          <div className="timeline-line" />

          {experiences.map((exp, i) => (
            <div
              key={i}
              className="exp-item"
              ref={(el) => (itemsRef.current[i] = el)}
            >
              <div className="exp-dot">
                <div className="exp-dot-inner" />
              </div>

              <div className="exp-card">
                <div className="exp-card-top">
                  <div>
                    <h3 className="exp-role">{exp.role}</h3>
                    <p className="exp-company">{exp.company}</p>
                  </div>
                  <div className="exp-meta">
                    <span className="exp-period">{exp.period}</span>
                    <span className="exp-location">{exp.location}</span>
                  </div>
                </div>

                <p className="exp-desc">{exp.desc}</p>

                <div className="exp-tags">
                  {exp.tags.map((tag) => (
                    <span key={tag} className="exp-tag">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;