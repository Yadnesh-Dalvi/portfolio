import React, { useRef, useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import "../styles/Projects.css";

gsap.registerPlugin(ScrollTrigger);

const projects = [
  {
    num: "01",
    title: "NeuralChat",
    category: "AI / Full-Stack",
    desc: "A real-time AI-powered chat application with context memory, streaming responses, and multi-model support. Built with React, FastAPI, and OpenAI APIs.",
    tags: ["React", "FastAPI", "OpenAI", "WebSockets"],
    year: "2024",
    color: "#800020",
  },
  {
    num: "02",
    title: "DataViz Studio",
    category: "Data Science",
    desc: "Interactive data visualization platform supporting CSV/JSON uploads, 12+ chart types, and AI-generated insights. Used by 500+ students at IU.",
    tags: ["D3.js", "Python", "Pandas", "Flask"],
    year: "2024",
    color: "#5c0017",
  },
  {
    num: "03",
    title: "CodeSync",
    category: "Real-Time App",
    desc: "Collaborative code editor with live cursors, video chat, and AI pair programming assistant. Supports 20+ languages with syntax highlighting.",
    tags: ["React", "Firebase", "Monaco Editor", "WebRTC"],
    year: "2023",
    color: "#3d0010",
  },
  {
    num: "04",
    title: "PortfolioGen",
    category: "Developer Tool",
    desc: "CLI tool that auto-generates beautiful portfolio websites from GitHub profiles using AI to write descriptions and project summaries.",
    tags: ["Node.js", "GitHub API", "GPT-4", "Handlebars"],
    year: "2023",
    color: "#800020",
  },
  {
    num: "05",
    title: "MedTrack",
    category: "Healthcare App",
    desc: "Medication tracking and reminder app with ML-based adherence predictions and caregiver dashboards. Tested with 50 participants in a clinical pilot.",
    tags: ["React Native", "TensorFlow", "MongoDB", "Express"],
    year: "2023",
    color: "#5c0017",
  },
];

const Projects = () => {
  const sectionRef = useRef(null);
  const trackRef = useRef(null);
  const titleRef = useRef(null);

  useEffect(() => {
    gsap.fromTo(titleRef.current,
        { opacity: 0, y: 50 },
        {
        opacity: 1, y: 0, duration: 1, ease: "power3.out",
        scrollTrigger: { trigger: titleRef.current, start: "top 80%" }
        }
    );

    const ctx = gsap.context(() => {
        const mm = gsap.matchMedia();

        mm.add("(min-width: 1px)", () => {
        const track = trackRef.current;

        // ✅ Defer calculation until after paint
        ScrollTrigger.refresh();

        const getTotal = () => track.scrollWidth - track.offsetWidth;

        const tween = gsap.to(track, {
            x: () => -getTotal(),
            ease: "none",
            scrollTrigger: {
            trigger: sectionRef.current,
            start: "top top",
            end: () => `+=${getTotal() + 400}`,
            pin: true,
            scrub: 1,
            anticipatePin: 1,
            invalidateOnRefresh: true, // ✅ Recalculates on resize/refresh
            },
        });

        return () => tween.kill();
        });

        return () => mm.revert();
    }, sectionRef);

    return () => ctx.revert();
    }, []);

  return (
    <section id="projects" className="proj-section" ref={sectionRef}>
      <div className="proj-header" ref={titleRef}>
        <span className="section-label">Selected Work</span>
        <h2 className="proj-title">Projects</h2>
        <p className="proj-hint">← Scroll to explore →</p>
      </div>

      <div className="proj-track-wrap">
        <div className="proj-track" ref={trackRef}>
          {projects.map((proj, i) => (
            <div className="proj-card" key={i} data-hover>
              <div className="proj-card-num">{proj.num}</div>
              <div className="proj-card-body">
                <div className="proj-card-top">
                  <span className="proj-category">{proj.category}</span>
                  <span className="proj-year">{proj.year}</span>
                </div>
                <h3 className="proj-name">{proj.title}</h3>
                <p className="proj-desc">{proj.desc}</p>
                <div className="proj-tags">
                  {proj.tags.map(tag => (
                    <span key={tag} className="proj-tag">{tag}</span>
                  ))}
                </div>
                <div className="proj-links">
                  <a href="#" className="proj-link">View Project →</a>
                  <a href="#" className="proj-link proj-link-ghost">GitHub</a>
                </div>
              </div>
              <div className="proj-card-accent" style={{ background: proj.color }} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
